import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Target,
  Server,
  Bell,
  Activity,
  History,
  Menu,
  X,
  ChevronLeft,
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const navItems = [
  { path: '/', label: '仪表盘', icon: LayoutDashboard },
  { path: '/tasks', label: '监控任务', icon: Target },
  { path: '/nodes', label: '监控节点', icon: Server },
  { path: '/alerts', label: '告警配置', icon: Bell },
  { path: '/status', label: '监控状态', icon: Activity },
  { path: '/history', label: '历史记录', icon: History },
];

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation();

  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-[#1E3A2F] text-white transition-all duration-300 z-50 ${
        collapsed ? 'w-16' : 'w-56'
      }`}
    >
      {/* Logo 区域 */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-[#2B5D3A]">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <Activity className="w-6 h-6 text-[#F5A623]" />
            <span className="font-bold text-lg">NetWatch</span>
          </div>
        )}
        <button
          onClick={onToggle}
          className="p-1.5 rounded-lg hover:bg-[#2B5D3A] transition-colors"
        >
          {collapsed ? <Menu className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
      </div>

      {/* 导航菜单 */}
      <nav className="p-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path ||
            (item.path !== '/' && location.pathname.startsWith(item.path));

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                isActive
                  ? 'bg-[#2B5D3A] text-white'
                  : 'text-gray-300 hover:bg-[#2B5D3A]/50 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && <span className="text-sm font-medium">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* 底部信息 */}
      {!collapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="p-3 bg-[#2B5D3A]/30 rounded-lg">
            <p className="text-xs text-gray-400 mb-1">版本信息</p>
            <p className="text-sm font-medium">NetWatch v1.0.0</p>
          </div>
        </div>
      )}
    </aside>
  );
}

interface HeaderProps {
  collapsed: boolean;
}

export function Header({ collapsed }: HeaderProps) {
  const location = useLocation();

  // 根据路径获取面包屑
  const getBreadcrumb = () => {
    const path = location.pathname;
    if (path === '/') return [{ label: '仪表盘' }];

    const routes: Record<string, string> = {
      '/tasks': '监控任务',
      '/nodes': '监控节点',
      '/alerts': '告警配置',
      '/status': '监控状态',
      '/history': '历史记录',
    };

    const mainRoute = routes[path] || path.split('/').pop();
    return [{ label: mainRoute }];
  };

  const breadcrumb = getBreadcrumb();

  return (
    <header
      className={`fixed top-0 right-0 h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 transition-all duration-300 z-40 ${
        collapsed ? 'left-16' : 'left-56'
      }`}
    >
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm">
        <span className="text-gray-500">首页</span>
        {breadcrumb.map((item, index) => (
          <span key={index} className="flex items-center gap-2">
            <span className="text-gray-400">/</span>
            <span className="text-gray-900 font-medium">{item.label}</span>
          </span>
        ))}
      </div>

      {/* 右侧操作 */}
      <div className="flex items-center gap-4">
        {/* 搜索框 */}
        <div className="relative">
          <input
            type="text"
            placeholder="搜索任务或节点..."
            className="w-64 px-4 py-2 pl-10 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#2B5D3A]/30 focus:border-[#2B5D3A]"
          />
          <svg
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>

        {/* 通知铃铛 */}
        <button className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors">
          <Bell className="w-5 h-5 text-gray-600" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        {/* 用户头像 */}
        <div className="flex items-center gap-2 pl-4 border-l border-gray-200">
          <div className="w-8 h-8 rounded-full bg-[#2B5D3A] flex items-center justify-center text-white text-sm font-medium">
            管
          </div>
          <span className="text-sm text-gray-700">管理员</span>
        </div>
      </div>
    </header>
  );
}

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <Sidebar collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} />
      <Header collapsed={collapsed} />
      <main
        className={`pt-16 min-h-screen transition-all duration-300 ${
          collapsed ? 'pl-16' : 'pl-56'
        }`}
      >
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
}
