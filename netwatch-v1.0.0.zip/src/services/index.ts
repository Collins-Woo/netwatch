/**
 * API Service Index
 *
 * 根据环境变量决定使用真实API还是Mock API
 * VITE_USE_MOCK_API=true - 使用Mock数据（前端Demo模式）
 * VITE_USE_MOCK_API=false - 使用真实后端API
 */

import * as mockApi from './mockApi';

// Determine which API to use
const useMockApi = import.meta.env.VITE_USE_MOCK_API !== 'false' || !import.meta.env.VITE_API_URL;

// Export the appropriate API
const api = useMockApi ? mockApi : (await import('./api').then(m => m.default));

export const tasksApi = api.tasks;
export const nodesApi = api.nodes;
export const alertsApi = api.alerts;
export const statusApi = api.status;
export const historyApi = api.history;
export const dashboardApi = api.dashboard;

export default api;
